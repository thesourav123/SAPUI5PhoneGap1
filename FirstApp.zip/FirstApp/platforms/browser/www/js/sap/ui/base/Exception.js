/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2012 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.base.Exception");
sap.ui.base.Exception=function(m){this.name="Exception";this.message=m};
